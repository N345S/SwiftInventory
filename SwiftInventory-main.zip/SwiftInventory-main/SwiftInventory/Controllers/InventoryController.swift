import Foundation

internal import Combine

class InventoryController: ObservableObject {
    
    @Published var inventory: [InventoryItem] = []
    
    private let persistence = PersistenceController.shared
    
    
    init(products: [Product]) {
        
        if let savedInventory = persistence.loadInventory() {
            inventory = savedInventory
        } else {
            loadSampleInventory(products: products)
            persistence.saveInventory(inventory)
        }
    }
    
    
    private func loadSampleInventory(products: [Product]) {
        inventory = [
            InventoryItem(product: products[0], quantity: 25),
            InventoryItem(product: products[1], quantity: 18),
            InventoryItem(product: products[2], quantity: 30),
            InventoryItem(product: products[3], quantity: 12),
            InventoryItem(product: products[4], quantity: 20)
        ]
    }
    
    
    func sellProduct(product: Product, quantity: Int) -> Bool {
        
        guard quantity > 0 else {
            return false
        }
        
        guard let index = inventory.firstIndex(where: {
            $0.product.id == product.id
        }) else {
            return false
        }
        
        guard inventory[index].quantity >= quantity else {
            return false
        }
        
        inventory[index].quantity -= quantity
        
        // Save the updated inventory
        persistence.saveInventory(inventory)
        
        return true
    }
    
    
    func updateStock(product: Product, quantity: Int) {
        
        guard let index = inventory.firstIndex(where: {
            $0.product.id == product.id
        }) else {
            return
        }
        
        inventory[index].quantity = max(0, quantity)
        
        // Save the updated inventory
        persistence.saveInventory(inventory)
    }
}
