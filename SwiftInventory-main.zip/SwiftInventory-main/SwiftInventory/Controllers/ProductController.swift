import Foundation
internal import Combine

class ProductController: ObservableObject {
    
    @Published var products: [Product] = [
        Product(
            name: "Coca-Cola 1.5L",
            category: "Drinks",
            costPrice: 45.00,
            sellingPrice: 60.00
        ),
        Product(
            name: "Sprite 1.5L",
            category: "Drinks",
            costPrice: 40.00,
            sellingPrice: 55.00
        ),
        Product(
            name: "Piattos",
            category: "Snacks",
            costPrice: 20.00,
            sellingPrice: 28.00
        ),
        Product(
            name: "Nova",
            category: "Snacks",
            costPrice: 18.00,
            sellingPrice: 25.00
        ),
        Product(
            name: "Lucky Me Pancit Canton",
            category: "Food",
            costPrice: 13.00,
            sellingPrice: 18.00
        )
    ]
}
