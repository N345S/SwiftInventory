import Foundation

internal import Combine

class SalesController: ObservableObject {
    
    @Published var sales: [Sale] = []
    
    private let persistence = PersistenceController.shared
    
    
    init() {
        sales = persistence.loadSales() ?? []
    }
    
    
    func addSale(
        transactionNumber: Int,
        product: Product,
        quantity: Int
    ) {
        
        let totalAmount = product.sellingPrice * Double(quantity)
        
        let totalProfit =
            (product.sellingPrice - product.costPrice)
            * Double(quantity)
        
        let newSale = Sale(
            transactionNumber: transactionNumber,
            product: product,
            quantity: quantity,
            totalAmount: totalAmount,
            totalProfit: totalProfit,
            date: Date()
        )
        
        sales.append(newSale)
        
        // Save the updated sales history
        persistence.saveSales(sales)
    }
}
