import Foundation

class PersistenceController {
    
    static let shared = PersistenceController()
    
    private init() {}
    
    private let inventoryKey = "saved_inventory"
    private let salesKey = "saved_sales"
    private let transactionNumberKey = "transaction_number"
    
    
    // MARK: - Inventory
    
    func saveInventory(_ inventory: [InventoryItem]) {
        if let data = try? JSONEncoder().encode(inventory) {
            UserDefaults.standard.set(data, forKey: inventoryKey)
        }
    }
    
    func loadInventory() -> [InventoryItem]? {
        guard let data = UserDefaults.standard.data(forKey: inventoryKey) else {
            return nil
        }
        
        return try? JSONDecoder().decode(
            [InventoryItem].self,
            from: data
        )
    }
    
    
    // MARK: - Sales
    
    func saveSales(_ sales: [Sale]) {
        if let data = try? JSONEncoder().encode(sales) {
            UserDefaults.standard.set(data, forKey: salesKey)
        }
    }
    
    func loadSales() -> [Sale]? {
        guard let data = UserDefaults.standard.data(forKey: salesKey) else {
            return nil
        }
        
        return try? JSONDecoder().decode(
            [Sale].self,
            from: data
        )
    }
    
    
    // MARK: - Transaction Number
    
    func saveTransactionNumber(_ number: Int) {
        UserDefaults.standard.set(
            number,
            forKey: transactionNumberKey
        )
    }
    
    func loadTransactionNumber() -> Int {
        let number = UserDefaults.standard.integer(
            forKey: transactionNumberKey
        )
        
        return number > 0 ? number : 1
    }
}
