import SwiftUI

struct InventoryView: View {
    
    @EnvironmentObject var appController: AppController
    
    @State private var searchText = ""
    @State private var selectedCategory = "All"
    
    private var categories: [String] {
        let productCategories = appController.productController.products.map {
            $0.category
        }
        
        return ["All"] + Array(Set(productCategories)).sorted()
    }
    
    private var filteredInventory: [InventoryItem] {
        appController.inventoryController.inventory.filter { item in
            let matchesSearch =
                searchText.isEmpty ||
                item.product.name.localizedCaseInsensitiveContains(searchText)
            
            let matchesCategory =
                selectedCategory == "All" ||
                item.product.category == selectedCategory
            
            return matchesSearch && matchesCategory
        }
    }
    
    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                SIHeader(
                    title: "Inventory",
                    subtitle: "Search products and update stock.",
                    icon: "shippingbox.fill"
                )
                
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        searchBar
                        categoryFilter
                        inventoryList
                    }
                    .padding()
                    .padding(.bottom, 20)
                }
            }
            .background(SITheme.background)
            .navigationBarHidden(true)
        }
    }
    
    private var searchBar: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(.secondary)
            
            TextField("Search products...", text: $searchText)
                .textInputAutocapitalization(.never)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 12)
        .siCard()
    }
    
    private var categoryFilter: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(categories, id: \.self) { category in
                    Button {
                        selectedCategory = category
                    } label: {
                        Text(category)
                            .font(.caption)
                            .fontWeight(.semibold)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 9)
                            .background(
                                selectedCategory == category
                                ? SITheme.blue
                                : SITheme.card
                            )
                            .foregroundStyle(
                                selectedCategory == category
                                ? .white
                                : .secondary
                            )
                            .clipShape(Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
    
    private var inventoryList: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Products")
                .font(.headline)
                .fontWeight(.bold)
            
            if filteredInventory.isEmpty {
                VStack(spacing: 10) {
                    Image(systemName: "shippingbox")
                        .font(.system(size: 34))
                        .foregroundStyle(.secondary)
                    
                    Text("No inventory found")
                        .font(.headline)
                    
                    Text("Try a different search or category.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 38)
                .siCard()
            } else {
                VStack(spacing: 12) {
                    ForEach(filteredInventory) { item in
                        InventoryCard(
                            item: item,
                            appController: appController
                        )
                    }
                }
            }
        }
    }
}

struct InventoryCard: View {
    
    let item: InventoryItem
    @ObservedObject var appController: AppController
    
    @State private var editedQuantity: Int
    
    init(item: InventoryItem, appController: AppController) {
        self.item = item
        self.appController = appController
        _editedQuantity = State(initialValue: item.quantity)
    }
    
    private var stockStatus: String {
        if item.quantity == 0 {
            return "Out of Stock"
        } else if item.quantity <= 5 {
            return "Low Stock"
        } else {
            return "In Stock"
        }
    }
    
    private var stockIcon: String {
        if item.quantity == 0 {
            return "xmark.circle.fill"
        } else if item.quantity <= 5 {
            return "exclamationmark.triangle.fill"
        } else {
            return "checkmark.circle.fill"
        }
    }
    
    private var stockColor: Color {
        if item.quantity == 0 {
            return .red
        } else if item.quantity <= 5 {
            return SITheme.orange
        } else {
            return SITheme.green
        }
    }
    
    private var hasChanges: Bool {
        editedQuantity != item.quantity
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 12) {
                ProductBadge(product: item.product, size: 50)
                
                VStack(alignment: .leading, spacing: 3) {
                    Text(item.product.name)
                        .font(.subheadline)
                        .fontWeight(.bold)
                        .lineLimit(1)
                    
                    Text(item.product.category)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    
                    Text("Stock: \(item.quantity)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                
                Spacer()
                
                VStack(alignment: .trailing, spacing: 7) {
                    Text("₱\(item.product.sellingPrice, specifier: "%.2f")")
                        .font(.subheadline)
                        .fontWeight(.bold)
                    
                    StatusBadge(
                        title: stockStatus,
                        icon: stockIcon,
                        color: stockColor
                    )
                }
            }
            
            Divider()
            
            HStack(spacing: 12) {
                Button {
                    editedQuantity = max(0, editedQuantity - 1)
                } label: {
                    Image(systemName: "minus")
                        .fontWeight(.bold)
                        .frame(width: 34, height: 34)
                        .background(Color(.systemGray6))
                        .foregroundStyle(editedQuantity > 0 ? SITheme.navy : .secondary)
                        .clipShape(Circle())
                }
                .disabled(editedQuantity == 0)
                
                Text("\(editedQuantity)")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 9)
                    .background(SITheme.softFill)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                
                Button {
                    editedQuantity += 1
                } label: {
                    Image(systemName: "plus")
                        .fontWeight(.bold)
                        .frame(width: 34, height: 34)
                        .background(Color(.systemGray6))
                        .foregroundStyle(SITheme.navy)
                        .clipShape(Circle())
                }
            }
            
            Button {
                appController.inventoryController.updateStock(
                    product: item.product,
                    quantity: editedQuantity
                )
            } label: {
                Text("Save Changes")
                    .font(.subheadline)
                    .fontWeight(.bold)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 13)
                    .background(hasChanges ? SITheme.green : Color(.systemGray5))
                    .foregroundStyle(hasChanges ? .white : .secondary)
                    .clipShape(RoundedRectangle(cornerRadius: 14))
            }
            .disabled(!hasChanges)
        }
        .padding()
        .siCard()
        .onChange(of: item.quantity) { _, newValue in
            editedQuantity = newValue
        }
    }
}

#Preview {
    InventoryView()
        .environmentObject(AppController())
}
