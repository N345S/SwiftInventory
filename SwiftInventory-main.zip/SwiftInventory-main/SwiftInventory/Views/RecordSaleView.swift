import SwiftUI

struct RecordSaleView: View {
    
    let product: Product
    
    @ObservedObject var inventoryController: InventoryController
    @ObservedObject var salesController: SalesController
    
    @State private var quantityText = "1"
    @State private var showError = false
    @State private var saleCompleted = false
    
    var quantity: Int {
        Int(quantityText) ?? 0
    }
    
    var totalAmount: Double {
        product.sellingPrice * Double(quantity)
    }
    
    var totalProfit: Double {
        (product.sellingPrice - product.costPrice)
        * Double(quantity)
    }
    
    var availableStock: Int {
        inventoryController.inventory.first {
            $0.product.id == product.id
        }?.quantity ?? 0
    }
    
    var body: some View {
        Form {
            
            Section("Product") {
                
                Text(product.name)
                    .font(.headline)
                
                Text(product.category)
                    .foregroundStyle(.secondary)
            }
            
            Section("Sale Information") {
                
                HStack {
                    Text("Selling Price")
                    
                    Spacer()
                    
                    Text(
                        "₱\(product.sellingPrice, specifier: "%.2f")"
                    )
                }
                
                HStack {
                    Text("Available Stock")
                    
                    Spacer()
                    
                    Text("\(availableStock)")
                        .fontWeight(.semibold)
                }
                
                TextField("Quantity", text: $quantityText)
                    .keyboardType(.numberPad)
            }
            
            Section("Summary") {
                
                HStack {
                    Text("Total Amount")
                    
                    Spacer()
                    
                    Text(
                        "₱\(totalAmount, specifier: "%.2f")"
                    )
                    .fontWeight(.bold)
                }
                
                HStack {
                    Text("Estimated Profit")
                    
                    Spacer()
                    
                    Text(
                        "₱\(totalProfit, specifier: "%.2f")"
                    )
                    .foregroundStyle(.green)
                    .fontWeight(.bold)
                }
            }
            
            Section {
                
                Button("Record Sale") {
                    recordSale()
                }
                .frame(maxWidth: .infinity)
            }
        }
        .navigationTitle("Record Sale")
        .alert("Invalid Sale", isPresented: $showError) {
            Button("OK", role: .cancel) {
            }
        } message: {
            Text(
                "Please enter a valid quantity that does not exceed the available stock."
            )
        }
        .alert("Sale Recorded", isPresented: $saleCompleted) {
            Button("OK") {
            }
        } message: {
            Text("The sale has been successfully recorded.")
        }
    }
    
    private func recordSale() {
        
        guard quantity > 0 else {
            showError = true
            return
        }
        
        guard quantity <= availableStock else {
            showError = true
            return
        }
        
        let success = inventoryController.sellProduct(
            product: product,
            quantity: quantity
        )
        
        if success {
            
            salesController.addSale(
                transactionNumber: salesController.sales.count + 1,
                product: product,
                quantity: quantity
            )
            
            saleCompleted = true
            
        } else {
            showError = true
        }
    }
}
