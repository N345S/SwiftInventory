import SwiftUI

struct ProductDetailView: View {
    
    let product: Product
    
    @ObservedObject var inventoryController: InventoryController
    @ObservedObject var salesController: SalesController
    
    @EnvironmentObject var appController: AppController
    
    @State private var addedToCart = false
    
    var currentStock: Int {
        inventoryController.inventory.first {
            $0.product.id == product.id
        }?.quantity ?? 0
    }
    
    var isInCart: Bool {
        appController.cart.contains {
            $0.product.id == product.id
        }
    }
    
    var body: some View {
        ScrollView {
            VStack(spacing: 20) {
                
                Image(systemName: "shippingbox.fill")
                    .font(.system(size: 70))
                    .frame(width: 120, height: 120)
                    .background(Color(.systemGray6))
                    .clipShape(RoundedRectangle(cornerRadius: 24))
                
                VStack(spacing: 6) {
                    Text(product.name)
                        .font(.title)
                        .fontWeight(.bold)
                        .multilineTextAlignment(.center)
                    
                    Text(product.category)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                
                VStack(spacing: 14) {
                    
                    ProductInfoRow(
                        title: "Cost Price",
                        value: String(
                            format: "₱%.2f",
                            product.costPrice
                        )
                    )
                    
                    Divider()
                    
                    ProductInfoRow(
                        title: "Selling Price",
                        value: String(
                            format: "₱%.2f",
                            product.sellingPrice
                        )
                    )
                    
                    Divider()
                    
                    ProductInfoRow(
                        title: "Available Stock",
                        value: "\(currentStock) units"
                    )
                }
                .padding()
                .background(Color(.systemGray6))
                .clipShape(RoundedRectangle(cornerRadius: 16))
                
                Button {
                    appController.addToCart(product: product)
                    addedToCart = true
                } label: {
                    HStack {
                        Image(systemName: "cart.badge.plus")
                        
                        Text(
                            isInCart
                            ? "Add Another to Cart"
                            : "Add to Cart"
                        )
                        .fontWeight(.semibold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(
                        currentStock > 0
                        ? Color.blue
                        : Color.gray
                    )
                    .foregroundStyle(.white)
                    .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                .disabled(currentStock <= 0)
                
                if isInCart {
                    NavigationLink {
                        CashierView()
                            .environmentObject(appController)
                    } label: {
                        HStack {
                            Image(systemName: "cart")
                            
                            Text("View Current Order")
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(.systemGray6))
                        .foregroundStyle(.primary)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                    }
                }
                
                Spacer()
            }
            .padding()
        }
        .navigationTitle("Product Details")
        .navigationBarTitleDisplayMode(.inline)
        .alert("Added to Cart", isPresented: $addedToCart) {
            Button("OK", role: .cancel) {}
        } message: {
            Text("\(product.name) has been added to the current order.")
        }
    }
}


// MARK: - Product Information Row

struct ProductInfoRow: View {
    
    let title: String
    let value: String
    
    var body: some View {
        HStack {
            Text(title)
                .foregroundStyle(.secondary)
            
            Spacer()
            
            Text(value)
                .fontWeight(.semibold)
        }
    }
}


#Preview {
    let product = Product(
        name: "Coca-Cola 1.5L",
        category: "Drinks",
        costPrice: 45.00,
        sellingPrice: 60.00
    )
    
    ProductDetailView(
        product: product,
        inventoryController: InventoryController(
            products: [product]
        ),
        salesController: SalesController()
    )
    .environmentObject(AppController())
}
