import Foundation

struct InventoryItem: Identifiable, Codable {
    
    var id: String {
        product.id
    }
    
    let product: Product
    var quantity: Int
}
