import Foundation

struct CartItem: Identifiable, Hashable {
    let id = UUID()
    
    let product: Product
    var quantity: Int
    
    var subtotal: Double {
        product.sellingPrice * Double(quantity)
    }
    
    var profit: Double {
        (product.sellingPrice - product.costPrice)
        * Double(quantity)
    }
}
