import Foundation

struct Sale: Identifiable, Codable {
    
    let id: UUID
    let transactionNumber: Int
    let product: Product
    let quantity: Int
    let totalAmount: Double
    let totalProfit: Double
    let date: Date
    
    init(
        transactionNumber: Int,
        product: Product,
        quantity: Int,
        totalAmount: Double,
        totalProfit: Double,
        date: Date
    ) {
        self.id = UUID()
        self.transactionNumber = transactionNumber
        self.product = product
        self.quantity = quantity
        self.totalAmount = totalAmount
        self.totalProfit = totalProfit
        self.date = date
    }
}
